from django import forms

class BookingForm(forms.Form):
    title = forms.ChoiceField(choices=[('MR', 'Mr'), ('MRS', 'Mrs'), ('MS', 'Ms')], required=True)
    first_name = forms.CharField(max_length=50, required=True)
    last_name = forms.CharField(max_length=50, required=True)
    phone = forms.CharField(max_length=15, required=True)
    email = forms.EmailField(required=True)
    card_vendor = forms.ChoiceField(choices=[('VI', 'Visa'), ('MC', 'MasterCard'), ('AX', 'American Express')], required=True)
    card_number = forms.CharField(max_length=16, required=True)
    card_expiry_date = forms.DateField(input_formats=['%m/%Y'], required=True, widget=forms.TextInput(attrs={'placeholder': 'MM/YYYY'}))
