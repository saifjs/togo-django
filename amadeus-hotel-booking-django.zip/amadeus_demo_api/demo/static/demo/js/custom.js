$(document).ready(function () {
    // Handle form submission
    $("#search-form").submit(function (e) {
        e.preventDefault();

        // ...

        // Show spinner
        $("#search-spinner").removeClass("d-none");

        // Perform AJAX request
        $.ajax({
            url: url,
            type: "GET",
            success: function (data) {
                $("#search-results").html(data);
            },
            error: function (xhr, status, error) {
                console.error("Error occurred: ", error);
            },
            complete: function () {
                // Hide spinner
                $("#search-spinner").addClass("d-none");
            }
        });
    });
});
